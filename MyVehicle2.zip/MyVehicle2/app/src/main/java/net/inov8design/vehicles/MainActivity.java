package net.inov8design.vehicles;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.app.FragmentManager;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import layout.Home_fragment;
import layout.Vehicle_fragment;
import layout.profile_fragment;
import layout.vehicle_list_fragment;
import net.inov8design.vehicles.Vehiclelogs;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;

import static net.inov8design.vehicles.DBAdapter.DATABASE_TABLE;
import static net.inov8design.vehicles.DBAdapter.KEY_DRIVER;
import static net.inov8design.vehicles.DBAdapter.KEY_ENDTIME;
import static net.inov8design.vehicles.DBAdapter.KEY_FB;
import static net.inov8design.vehicles.DBAdapter.KEY_REGO;
import static net.inov8design.vehicles.DBAdapter.KEY_ROWID;
import static net.inov8design.vehicles.DBAdapter.KEY_SB;
import static net.inov8design.vehicles.DBAdapter.KEY_STARTTIME;
import static net.inov8design.vehicles.DBAdapter.KEY_VEHICLETYPE;


public class MainActivity extends Activity {
    int currentPage = 0;
    public static String pageNames[] = {"Car","5T Truck","10T Truck","Tipper","Articulated"};
    public static ArrayList<Vehiclelogs> entries = new ArrayList<Vehiclelogs>();

    @Override
    protected void onStart(){
        super.onStart();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FragmentManager fragmentmanager = getFragmentManager();
        FragmentTransaction ft = fragmentmanager.beginTransaction();
        Home_fragment hf = new Home_fragment();
        ft.replace(R.id.carPlace, hf);
        ft.commit();

        setContentView(R.layout.activity_main);

        DBAdapter db = new DBAdapter(this);
        try {

            String destPath = "/data/data/" + getPackageName() +
                    "/databases";

            File f = new File(destPath);
            if (!f.exists()) {
                f.mkdirs();
                f.createNewFile();

                //---copy the db from the assets folder into
                // the databases folder---
                CopyDB(getBaseContext().getAssets().open("vehiclelog"),
                        new FileOutputStream(destPath + "/Vehiclelog"));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //---get all contacts---
        db.open();
       // int itemcount = db.getItemcount();

        Cursor c = db.getAlllogs();
        if (c.moveToFirst())
        {
            do {
                Vehiclelogs newvehicle = new Vehiclelogs(c.getInt(c.getColumnIndex("vehicletype")), c.getString(c.getColumnIndex("driver")), c.getString(c.getColumnIndex("rego")), c.getString(c.getColumnIndex("starttime")),c.getString(c.getColumnIndex("firstbreak")), c.getString(c.getColumnIndex("secondbreak")),c.getString(c.getColumnIndex("endtime")) );
                MainActivity.entries.add(newvehicle);
                //DisplayContact(c);
            } while (c.moveToNext());
        }
        db.close();
    }

    public void CopyDB(InputStream inputStream,
                       OutputStream outputStream) throws IOException {
        //---copy 1K bytes at a time---
        byte[] buffer = new byte[1024];
        int length;
        while ((length = inputStream.read(buffer)) > 0) {
            outputStream.write(buffer, 0, length);
        }
        inputStream.close();
        outputStream.flush();
        outputStream.close();
    }


    public void onSaveInstanceState(Bundle outState){
        super.onSaveInstanceState(outState);
    }
    public void onRestorInstanceState(Bundle savedInstanceSate){
        super.onRestoreInstanceState(savedInstanceSate);
    }
    public void onClick(View view){
        currentPage = Integer.valueOf((String)view.getTag());
        showCurrentPage();
    }

    public void showCurrentPage(){

        //Toast.makeText(MainActivity.this,"Current Page:"+currentPage ,Toast.LENGTH_SHORT).show();
        if (currentPage == 0){
            FragmentManager fragmentmanager = getFragmentManager();
            FragmentTransaction ft = fragmentmanager.beginTransaction();
            Home_fragment hf = new Home_fragment();
            ft.replace(R.id.carPlace, hf);
            ft.commit();
        }else{
            FragmentManager fragmentmanager = getFragmentManager();
            Vehicle_fragment vf = new Vehicle_fragment();
            Bundle args = new Bundle();
            args.putInt("vehicle",currentPage);
            vf.setArguments(args);
            FragmentTransaction ft = fragmentmanager.beginTransaction();
            ft.replace(R.id.carPlace, vf);
            ft.commit();
        }

    }
    public void prev(View view){
        currentPage = currentPage -1;
        if(currentPage <= 0) {
            currentPage = 5;
        }

        showCurrentPage();
    }
    public void next(View view){
        currentPage = currentPage +1;
        if(currentPage > 5) {
            currentPage = 1;
        }

        showCurrentPage();
    }
    public void home(View view){
        currentPage = 0;


        showCurrentPage();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.themenu,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        return MenuChoice(item);
    }
    private Boolean MenuChoice(MenuItem item) {

        DBAdapter db = new DBAdapter(this);
        switch (item.getItemId()) {
            case R.id.profile:
                FragmentManager fragmentmanager = getFragmentManager();
                FragmentTransaction ft = fragmentmanager.beginTransaction();
                profile_fragment pf = new profile_fragment();
                ft.replace(R.id.carPlace, pf);
                ft.commit();
                return true;
            case R.id.deletedb:
                db.open();
                db.deletealllogs();
                db.close();
                Toast.makeText(MainActivity.this,"Database has been deleted",Toast.LENGTH_SHORT).show();
                return true;

            case R.id.save:

                db.open();
                db.deletealllogs();
                Iterator itr = (Iterator) MainActivity.entries.iterator();
                //Iterator over array and save each entry to the database.
                while (itr.hasNext()){
                    Vehiclelogs vehicleitem = (Vehiclelogs) itr.next();
                    db.insertlog(vehicleitem.getDriver(), vehicleitem.getRego(),  vehicleitem.getStarttime(), vehicleitem.getFb(),vehicleitem.getSb(),vehicleitem.getEndtime(),vehicleitem.getVehicleid());
                }
                Toast.makeText(MainActivity.this,"Data Has Been Saved",Toast.LENGTH_SHORT).show();
                int itemcount = db.getItemcount();
                Toast.makeText(MainActivity.this,itemcount + " items in the database",Toast.LENGTH_SHORT).show();
                db.close();
                return true;

            case R.id.send:

                final Context ctx = this;
                Builder builder = new AlertDialog.Builder(this);
                //builder.setIcon(R.drawable.ic_launcher);
                builder.setTitle("Do you want to send an email");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener()
                        {
                            public void onClick(DialogInterface dialog, int whichButton)
                            {
                                DBAdapter db = new DBAdapter(ctx);
                                db.open();
                                Toast.makeText(getBaseContext(), "OK clicked!", Toast.LENGTH_SHORT).show();
                                String[] to ={"dianchao.chen@cqumail.com"};
                                String[] cc = {"dianchao.chen@gmail.com"};
                                String message = "";
                                Iterator itr = (Iterator) MainActivity.entries.iterator();
                                int count = db.getItemcount();
                                for (int i=0; i<count; i++)
                                {
                                    Vehiclelogs item = (Vehiclelogs) itr.next();
                                    message = message + "Driver: " + item.getDriver()+ "Rego: " + item.getRego()+ item.getStarttime() + item.getFb()+ item.getSb()+ item.getEndtime()+"\r\n";
                                }
                                sendEmail(to, cc, "Vehicle Details", message);
                                db.deletealllogs();
                                db.close();
                            }
                        }
                );
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
                        {
                            public void onClick(DialogInterface dialog, int whichButton)
                            {
                                Toast.makeText(getBaseContext(), "Cancel clicked!", Toast.LENGTH_SHORT).show();
                            }
                        }
                );
                builder.create().show();
                return true;

        }
        return true;
    }

    private void sendEmail(String[] emailAddresses, String[] carbonCopies,
                           String subject, String message)
    {
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        String[] to = emailAddresses;
        String[] cc = carbonCopies;
        emailIntent.putExtra(Intent.EXTRA_EMAIL, to);
        emailIntent.putExtra(Intent.EXTRA_CC, cc);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        emailIntent.putExtra(Intent.EXTRA_TEXT, message);
        emailIntent.setType("message/rfc822");
        startActivity(Intent.createChooser(emailIntent, "Email"));
    }

    public static boolean isEmpty(TextView txtview){

        return txtview.getText().toString().trim().length() ==0;
    }
}
